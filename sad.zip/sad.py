from flask import Flask

app = Flask(__name__)


@app.route('/')
def kfjjshdf():
    return "Колонизация Марса"


@app.route('/index')
def index():
    return 'И на Марсе будут яблони цвести!'


@app.route('/promotion')
def promotion():
    countdown_list = '''Человечество вырастает из детства.
    Человечеству мала одна планета.
    Мы сделаем обитаемыми безжизненные пока планеты.
    И начнем с Марса!
    Присоединяйся!'''.split('\n')
    return '</br>'.join(countdown_list)


@app.route('/image_mars')
def image_mars():
    return '''
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Привет, Марс!</title>
    </head>
    <body>
        <h1>Жди нас, Марс!</h1>
        <img src="img/Mars.jpg" alt="Марс" width="500">
        <p>Вот она какая, красная планета.</p>
    </body>
    </html>
    '''

@app.route('/promotion_image')
def promotion_image():
    promotion_lines = [
        "Человечество вырастает из детства.",
        "Человечеству мала одна планета.",
        "Мы сделаем обитаемыми безжизненные пока планеты.",
        "И начнем с Марса!",
        "Присоединяйся!"
    ]

    lines_html = ""
    for i, line in enumerate(promotion_lines):
        lines_html += f'<p class="mb-2">{line}</p>'
        if i != len(promotion_lines) - 1:
            lines_html += '<hr>'

    return  '''<!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Привет, Марс!</title>
    </head>
    <body>
        <h1>Жди нас, Марс!</h1>
        <img src="{{ url_for('static', filename='img/Mars.jpg') }}" alt="Марс" width="500">
        <p>Вот она какая, красная планета.</p>
        '{lines_html}'
    </body>
    </html>
    '''



if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')