from flask import Flask, render_template, request, session, redirect, url_for
from flask_login import login_user, login_required, logout_user
from random import choice
from forms.users import LoginForm, RegisterForm
from db import db_session
from db.users import Users

app = Flask(__name__)
app.secret_key = 'slava_zelalovoy'


for code in [400,401, 403]:
    @app.errorhandler(code)
    def handle_error(error):
        return f"Ошибка {error.code}", error.code



@app.route('/game', methods=['GET', 'POST'])
def game():
    global possible
    # Инициализация уровня (0 - обычный, 1 - сложный)
    if 'level' not in session:
        session['level'] = 0

    message = ''

    # Обработка переключения уровня (УБИРАЕМ ПРОВЕРКУ НА ИСТОРИЮ)
    if request.method == 'POST' and 'toggle_level' in request.form:
        # Переключаем уровень
        print(f"Уровень после переключения: {session['level']}")
        session['level'] = 1 - session['level']
        # Полностью сбрасываем игру
        session['secret'] = generate_secret_number()
        session['attempts'] = 0
        session['history'] = []
        if session['level'] == 1:
            possible = generate_all()
        return redirect(url_for('game'))


    if request.method == 'POST' and 'guess' in request.form and session['level'] == 0:
        guess = request.form.get('guess', '')
        # Получаем историю, гарантируя что это список
        history = session.get('history', []) or []

        if any(str(attempt['guess']) == str(guess) for attempt in history):
            message = "Это число уже было введено ранее!"
            # return render_template(
            #     'index.html',
            #     message=message,
            #     history=history,
            #     attempts=session.get('attempts', 0)
            # )
        # можно через message = "Введите 4 уникальные цифры!
        # Валидация ввода
        if len(guess) != 4 or not guess.isdigit() or len((guess)) != 4:
            message = "Введите 4 уникальные цифры!"
        else:
            session['attempts'] += 1
            bulls, cows = calculate_score(session['secret'], guess)

            # Добавляем попытку в историю
            session['history'].append({
                'guess': guess,
                'bulls': bulls,
                'cows': cows
            })
            if bulls == 4:
                # if 'user_id' in session:  # Если пользователь авторизован
                #     db_sess = db_session.create_session()
                #     user = db_sess.query(User).get(session['user_id'])
                #
                #     # Обновляем рекорд для текущего режима
                #     if session.get('level', 0) == 0:
                #         if user.normal_highscore == 0 or session['attempts'] < user.normal_highscore:
                #             user.normal_highscore = session['attempts']
                #     else:
                #         if user.advanced_highscore == 0 or session['attempts'] < user.advanced_highscore:
                #             user.advanced_highscore = session['attempts']
                #
                #     db_sess.commit()
                message = f"Победа! Число {session['secret']} угадано за {session['attempts']} попыток!"
                # session['record'] = min(session['record'], session['sttempts'])
                # Сброс игры после победы
                current_level = session.get('level', 0)
                session.clear()
                session['level'] = current_level
                return render_template('index.html',
                       message=message,
                       history=[],
                       attempts=0,
                       level=current_level)
            else:
                message = f"Быки: {bulls}, Коровы: {cows}"

    if request.method == 'POST' and 'guess' in request.form and session['level'] == 1: # cекретный уровень
        guess = request.form.get('guess', '')
        # Получаем историю, гарантируя что это список
        history = session.get('history', []) or []
        if len(guess) != 4 or not guess.isdigit() or len((guess)) != 4:
            message = "Введите 4 уникальные цифры!"
        else:
            session['attempts'] += 1
            bulls, cows = calculate_score(session['secret'], guess)
            possible = filter_possible_numbers(possible, session['secret'], bulls, cows, guess)
            session['secret'] = choice(possible)
            # Добавляем попытку в историю
            session['history'].append({
                'guess': guess,
                'bulls': bulls,
                'cows': cows
            })
            if bulls == 4:
                # if 'user_id' in session:  # Если пользователь авторизован
                #     db_sess = db_session.create_session()
                #     user = db_sess.query(User).get(session['user_id'])
                #
                #     # Обновляем рекорд для текущего режима
                #     if session.get('level', 0) == 0:
                #         if user.normal_highscore == 0 or session['attempts'] < user.normal_highscore:
                #             user.normal_highscore = session['attempts']
                #     else:
                #         if user.advanced_highscore == 0 or session['attempts'] < user.advanced_highscore:
                #             user.advanced_highscore = session['attempts']
                #
                #     db_sess.commit()
                message = f"Победа! Число {session['secret']} угадано за {session['attempts']} попыток!"
                # session['record'] = min(session['record'], session['sttempts'])
                # Сброс игры после победы
                current_level = session.get('level', 0)
                session.clear()
                session['level'] = current_level
                return render_template('index.html',
                                       message=message,
                                       history=[],
                                       attempts=0,
                                       level=current_level)
            else:
                message = f"Быки: {bulls}, Коровы: {cows}"

    return render_template('index.html',
                           message=message,
                           history=session.get('history', []),
                           attempts=session.get('attempts', 0),
                           level=session.get('level', 0))


def reset_game_state():
    """Сбрасывает игровое состояние, сохраняя уровень"""
    level = session.get('level', 0)

    session.update({
        'secret': generate_secret_number(),
        'attempts': 0,
        'history': [],
        'level': level,
        'possible': generate_all() if level == 1 else [],
        'record' : [10000, 100000]
    })

def generate_secret_number():
    """Генерирует 4-значное число без повторяющихся цифр"""
    from random import sample
    return ''.join(sample('0123456789', 4))

def generate_secret_secret_number():
    pass

def generate_all():
    """Генерирует 4-значное число с уникальными цифрами"""
    numbers = []
    for num in range(1000, 10000):
        digits = str(num)
        # Проверяем, что все цифры уникальны
        if len(set(digits)) == 4:
            numbers.append(digits)
    return numbers

possible = generate_all()
def filter_possible_numbers(possible_numbers, secret, bulls, cows, current_guess):
    """Фильтрует возможные числа на основе последней попытки"""
    return [num for num in possible_numbers
            if calculate_score(num, current_guess) == (bulls, cows)]

def calculate_score(secret, guess):
    bulls, cows = 0, 0
    for i in range(4):
        if secret[i] == guess[i]:
            bulls += 1
        elif guess[i] in secret:
            cows += 1
    return bulls, cows


@app.route('/new_game')
def new_game():
    session.pop('secret', None)
    session.pop('attempts', None)
    session.pop('history', None)
    return redirect(url_for('game'))


@app.route('/velikyphilolog')
def philolog():
    promotion_lines = ["Это профиль человека, при жизни ставшей легендой",
                       "Народный артист и филолог Советского Союза, России, всей вселенной и даже Чечено-Ингушетии",
                       "Председатель партии ЯБЛОКО",
                       "Методист ВСЕЯ Руси, ИМЦ планеты Плутон",
                       "Лауреат государственной премии СССР и премии 'ТЭФИ'",
                       "Человек признанный, известный, авторитетный, мэтр",
                       "Человек который творил эту эпоху, и который сам стал эпохой",
                       "Человек которого я очень уважаю и люблю"
                       ]
    return render_template('SAVelikaya.html', lines=promotion_lines)


@app.route('/rules')
def rules():
    rules_sections1 = ["Компьютер загадывает число длиной 4 (можно усложнить по количеству символов)",
                       "Все цифры в числе уникальны и оно не начинается с нуля",
                       "Вы вводите свои варианты числа той же длины",
                       "Цель - угадать число за минимальное количество попыток"]

    rules_sections2 = ["Компьютер может менять загаданное число после каждой попытки,",
                       "но так, чтобы сохранялась логика предыдущих ответов",
                       "Новое число должно соответствовать всем предыдущим подсказкам",
                       "Это делает игру сложнее - число может 'убегать' от ваших догадок",
                       "Победа наступает, когда вы угадываете текущее число"]

    base_r = ["'Бык' (Б) -> Цифра есть в числе и стоит на своём месте",
              "'Корова' (К) -> Цифра есть в числе, но не на своём месте"]

    return render_template('rules.html',
                           page_title_base="Правила игры 'Быки и коровы'",
                           base_rule=base_r,
    intro_text_1 = "Базовый уровень (4 цифры)",
    sections_1 = rules_sections1,
    intro_text_2 = "Усложненный уровень (4 цифры)",
    sections_2 = rules_sections2
    )





"""@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect('/login')

    db_sess = db_session.create_session()
    user = db_sess.query(User).get(session['user_id'])

    return render_template('profile.html',
                           title='Профиль',
                           user=user,
                           normal_highscore=user.normal_highscore,
                           advanced_highscore=user.advanced_highscore)
"""

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")

@app.route('/')
def index():
    return redirect(url_for('reqister'))


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if request.method == 'POST':
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(Users).filter(Users.email == form.email.data).first():
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Такой пользователь уже есть")
        if form.date_of_birth.data > date.today():
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Указана дата рождения из будующего")
        user = Users(
            email=form.email.data,
            name=form.name.data,
            surname1=form.surname1.data,
            surname2=form.surname2.data,
            date_of_birth=str(form.date_of_birth.data).split()[-1])
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        db_sess.close()
        return redirect('/')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if request.method == 'POST':
        db_sess = db_session.create_session()
        user = db_sess.query(Users).filter(Users.email == form.email.data).first()
        db_sess.close()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html', title='Авторизация', message="Неправильный логин или пароль", form=form)
    return render_template('login.html', title='Авторизация', form=form)


if __name__ == '__main__':
    app.run(debug=True)
